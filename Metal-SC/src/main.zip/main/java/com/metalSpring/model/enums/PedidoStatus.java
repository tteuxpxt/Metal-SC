package com.metalSpring.model.enums;

public enum PedidoStatus {
    PENDENTE,
    CONFIRMADO,
    EM_SEPARACAO,
    ENVIADO,
    ENTREGUE,
    CANCELADO
}