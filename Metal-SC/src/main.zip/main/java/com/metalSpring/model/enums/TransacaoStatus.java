package com.metalSpring.model.enums;

public enum TransacaoStatus {
    PENDENTE,
    PROCESSANDO,
    CONFIRMADA,
    RECUSADA,
    ESTORNADA
}