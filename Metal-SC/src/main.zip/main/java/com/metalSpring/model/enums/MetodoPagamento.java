package com.metalSpring.model.enums;

public enum MetodoPagamento {
    CARTAO_CREDITO,
    CARTAO_DEBITO,
    PIX,
    BOLETO,
    TRANSFERENCIA_BANCARIA
}