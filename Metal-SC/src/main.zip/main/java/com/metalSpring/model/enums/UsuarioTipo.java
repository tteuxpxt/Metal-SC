package com.metalSpring.model.enums;

public enum UsuarioTipo {
    CLIENTE,
    REVENDEDOR,
    ADMINISTRADOR
}