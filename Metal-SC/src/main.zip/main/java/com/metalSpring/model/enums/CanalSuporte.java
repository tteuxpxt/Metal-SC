package com.metalSpring.model.enums;

public enum CanalSuporte {
    EMAIL,
    CHAT,
    TELEFONE,
    WHATSAPP
}