package com.metalSpring.model.enums;

public enum PecaEstado {
    NOVO,
    USADO,
    RECONDICIONADO,
    DEFEITUOSO
}