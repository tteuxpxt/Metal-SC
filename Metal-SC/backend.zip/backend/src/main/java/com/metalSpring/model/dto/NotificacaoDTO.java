package com.metalSpring.model.dto;

import java.time.LocalDateTime;

public class NotificacaoDTO {
    private String conversaId;
    private String mensagemId;
    private String pecaNome;
    private String remetenteNome;
    private String trechoMensagem;
    private LocalDateTime dataEnvio;
    private long naoLidas;

    public String getConversaId() { return conversaId; }
    public void setConversaId(String conversaId) { this.conversaId = conversaId; }

    public String getMensagemId() { return mensagemId; }
    public void setMensagemId(String mensagemId) { this.mensagemId = mensagemId; }

    public String getPecaNome() { return pecaNome; }
    public void setPecaNome(String pecaNome) { this.pecaNome = pecaNome; }

    public String getRemetenteNome() { return remetenteNome; }
    public void setRemetenteNome(String remetenteNome) { this.remetenteNome = remetenteNome; }

    public String getTrechoMensagem() { return trechoMensagem; }
    public void setTrechoMensagem(String trechoMensagem) { this.trechoMensagem = trechoMensagem; }

    public LocalDateTime getDataEnvio() { return dataEnvio; }
    public void setDataEnvio(LocalDateTime dataEnvio) { this.dataEnvio = dataEnvio; }

    public long getNaoLidas() { return naoLidas; }
    public void setNaoLidas(long naoLidas) { this.naoLidas = naoLidas; }
}
