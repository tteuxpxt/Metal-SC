package com.metalSpring.model.dto;

public class NegociacaoDenunciaDTO {
    private String usuarioId;
    private String motivo;

    public String getUsuarioId() { return usuarioId; }
    public void setUsuarioId(String usuarioId) { this.usuarioId = usuarioId; }
    public String getMotivo() { return motivo; }
    public void setMotivo(String motivo) { this.motivo = motivo; }
}
