const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8080/api';

const getAuthHeader = () => {
  const token = localStorage.getItem('metal_auth');
  return token ? { Authorization: `Bearer ${token}` } : {};
};

const request = async (path, options = {}) => {
  const { headers, auth = true, ...rest } = options;
  const res = await fetch(`${API_URL}${path}`, {
    ...rest,
    headers: {
      'Content-Type': 'application/json',
      ...(auth ? getAuthHeader() : {}),
      ...(headers || {})
    }
  });

  if (res.status === 204) {
    return null;
  }

  let data = null;
  const contentType = res.headers.get('content-type') || '';
  if (contentType.includes('application/json')) {
    data = await res.json();
  } else {
    data = await res.text();
  }

  if (!res.ok) {
    if (res.status === 401 && auth) {
      localStorage.removeItem('metal_auth');
      localStorage.removeItem('metal_user');
      window.dispatchEvent(new Event('metal:unauthorized'));
    }

    const message =
      (data && data.error) ||
      (data && data.message) ||
      (typeof data === 'string' && data) ||
      'Erro na requisição';
    throw new Error(message);
  }

  return data;
};

export const fetchPecas = () => request('/pecas');

export const fetchPecasByRevendedor = (revendedorId) =>
  request(`/pecas/revendedor/${revendedorId}`);

export const fetchPedidosByCliente = (clienteId) =>
  request(`/pedidos/cliente/${clienteId}`);

export const fetchPedidosByRevendedor = (revendedorId) =>
  request(`/pedidos/revendedor/${revendedorId}`);

export const fetchRevendedorById = (revendedorId) =>
  request(`/revendedores/${revendedorId}`);

export const fetchClienteById = (clienteId) =>
  request(`/clientes/${clienteId}`);

export const fetchPerfilById = (perfilId) =>
  request(`/perfis/${perfilId}`);

export const updatePerfil = (perfilId, payload) =>
  request(`/perfis/${perfilId}`, {
    method: 'PUT',
    body: JSON.stringify(payload)
  });

export const fetchComentariosPerfilByAlvo = (alvoId) =>
  request(`/comentarios-perfil/alvo/${alvoId}`);

export const fetchComentarioPerfilMedia = (alvoId) =>
  request(`/comentarios-perfil/alvo/${alvoId}/media`);

export const createComentarioPerfil = (payload) =>
  request('/comentarios-perfil', {
    method: 'POST',
    body: JSON.stringify(payload)
  });

export const deleteComentarioPerfil = (comentarioId) =>
  request(`/comentarios-perfil/${comentarioId}`, { method: 'DELETE' });

export const updateCliente = (clienteId, payload) =>
  request(`/clientes/${clienteId}`, {
    method: 'PUT',
    body: JSON.stringify(payload)
  });

export const updateRevendedor = (revendedorId, payload) =>
  request(`/revendedores/${revendedorId}`, {
    method: 'PUT',
    body: JSON.stringify(payload)
  });

export const uploadUsuarioFoto = async (usuarioId, file) => {
  const formData = new FormData();
  formData.append('file', file);

  const res = await fetch(`${API_URL}/usuarios/${usuarioId}/foto`, {
    method: 'POST',
    headers: {
      ...getAuthHeader()
    },
    body: formData
  });

  let data = null;
  const contentType = res.headers.get('content-type') || '';
  if (contentType.includes('application/json')) {
    data = await res.json();
  } else {
    data = await res.text();
  }

  if (!res.ok) {
    const message =
      (data && data.error) ||
      (data && data.message) ||
      (typeof data === 'string' && data) ||
      'Erro ao enviar foto';
    throw new Error(message);
  }

  return data;
};

export const confirmarPagamentoPedido = (pedidoId) =>
  request(`/pedidos/${pedidoId}/confirmar-pagamento`, { method: 'POST' });

export const informarPagamentoPedido = (pedidoId, clienteId) => {
  const query = clienteId ? `?clienteId=${encodeURIComponent(clienteId)}` : '';
  return request(`/pedidos/${pedidoId}/informar-pagamento${query}`, { method: 'POST' });
};

export const liberarPagamentoPedido = (pedidoId) =>
  request(`/pedidos/${pedidoId}/liberar-pagamento`, { method: 'POST' });

export const fetchUsuarioPorEmail = (email) =>
  request(`/usuarios/email/${encodeURIComponent(email)}`);

export const loginUsuario = (email, senha) =>
  request('/auth/login', {
    method: 'POST',
    auth: false,
    body: JSON.stringify({ email, senha })
  });

export const registerUsuario = (payload, tipo) => {
  const endpoint = tipo === 'CLIENTE' ? '/clientes' : '/revendedores';
  return request(endpoint, {
    method: 'POST',
    auth: false,
    body: JSON.stringify(payload)
  });
};

export const savePeca = (pecaData, revendedorId, pecaId) => {
  const payload = {
    ...pecaData,
    revendedorId
  };
  const method = pecaId ? 'PUT' : 'POST';
  const endpoint = pecaId ? `/pecas/${pecaId}` : '/pecas';
  return request(endpoint, {
    method,
    body: JSON.stringify(payload)
  });
};

export const deletePeca = (pecaId) =>
  request(`/pecas/${pecaId}`, { method: 'DELETE' });

export const createPedido = (pedido) =>
  request('/pedidos', {
    method: 'POST',
    headers: {
      Accept: 'application/json'
    },
    body: JSON.stringify(pedido)
  });

export const uploadPecaImagem = async (pecaId, file) => {
  const formData = new FormData();
  formData.append('file', file);

  const res = await fetch(`${API_URL}/pecas/${pecaId}/imagens/upload`, {
    method: 'POST',
    headers: {
      ...getAuthHeader()
    },
    body: formData
  });

  let data = null;
  const contentType = res.headers.get('content-type') || '';
  if (contentType.includes('application/json')) {
    data = await res.json();
  } else {
    data = await res.text();
  }

  if (!res.ok) {
    const message =
      (data && data.error) ||
      (data && data.message) ||
      (typeof data === 'string' && data) ||
      'Erro ao enviar imagem';
    throw new Error(message);
  }

  return data;
};

export const removePecaImagem = (pecaId, imageUrl) =>
  request(`/pecas/${pecaId}/imagens?url=${encodeURIComponent(imageUrl)}`, {
    method: 'DELETE'
  });

export const denunciarPecaImagem = (pecaId, payload) =>
  request(`/pecas/${pecaId}/imagens/denunciar`, {
    method: 'POST',
    body: JSON.stringify(payload)
  });

export const fetchAdminDashboard = () => request('/admin/dashboard');

export const fetchAdminUsuarios = () => request('/admin/usuarios');

export const fetchAdminRevendedores = () => request('/admin/revendedores');

export const deleteAdminUsuario = (usuarioId) =>
  request(`/admin/usuarios/${usuarioId}`, { method: 'DELETE' });

export const deleteAdminRevendedor = (revendedorId) =>
  request(`/admin/revendedores/${revendedorId}`, { method: 'DELETE' });

export const baixarTaxasRevendedor = (revendedorId, valor) => {
  const query = valor !== null && valor !== undefined ? `?valor=${encodeURIComponent(valor)}` : '';
  return request(`/admin/revendedores/${revendedorId}/taxas/baixar${query}`, {
    method: 'POST'
  });
};

export const ativarPremiumRevendedor = (revendedorId, dias) => {
  const query = dias ? `?dias=${encodeURIComponent(dias)}` : '';
  return request(`/admin/revendedores/${revendedorId}/premium${query}`, {
    method: 'POST'
  });
};

export const desativarPremiumRevendedor = (revendedorId) =>
  request(`/admin/revendedores/${revendedorId}/premium`, { method: 'DELETE' });

export const fetchNegociacoesCliente = (clienteId) =>
  request(`/negociacoes/cliente/${clienteId}`);

export const fetchNegociacoesRevendedor = (revendedorId) =>
  request(`/negociacoes/revendedor/${revendedorId}`);

export const fetchNegociacao = (conversaId, visualizadorId) => {
  const query = visualizadorId ? `?visualizadorId=${encodeURIComponent(visualizadorId)}` : '';
  return request(`/negociacoes/${conversaId}${query}`);
};

export const fetchNotificacoesContagem = (usuarioId) =>
  request(`/negociacoes/notificacoes/${usuarioId}/contagem`);

export const fetchNotificacoes = (usuarioId) =>
  request(`/negociacoes/notificacoes/${usuarioId}`);

export const enviarMensagemNegociacao = (conversaId, payload) =>
  request(`/negociacoes/${conversaId}/mensagens`, {
    method: 'POST',
    body: JSON.stringify(payload)
  });

export const enviarContrapropostaNegociacao = (conversaId, payload) =>
  request(`/negociacoes/${conversaId}/contraproposta`, {
    method: 'POST',
    body: JSON.stringify(payload)
  });

export const aceitarNegociacao = (conversaId, remetenteId) =>
  request(`/negociacoes/${conversaId}/aceitar`, {
    method: 'POST',
    body: JSON.stringify({ remetenteId })
  });

export const aprovarNegociacao = (conversaId, remetenteId) =>
  request(`/negociacoes/${conversaId}/aprovar`, {
    method: 'POST',
    body: JSON.stringify({ remetenteId })
  });

export const recusarNegociacao = (conversaId, remetenteId) =>
  request(`/negociacoes/${conversaId}/recusar`, {
    method: 'POST',
    body: JSON.stringify({ remetenteId })
  });

export const encerrarNegociacao = (conversaId, usuarioId, status = 'CANCELADO') =>
  request(`/negociacoes/${conversaId}/encerrar?usuarioId=${encodeURIComponent(usuarioId)}&status=${encodeURIComponent(status)}`, {
    method: 'POST'
  });

export const marcarNegociacaoLida = (conversaId, usuarioId) =>
  request(`/negociacoes/${conversaId}/lidas?usuarioId=${encodeURIComponent(usuarioId)}`, {
    method: 'POST'
  });

export const fetchModeracaoAlertas = (filters = {}) => {
  const params = new URLSearchParams();
  Object.entries(filters).forEach(([key, value]) => {
    if (value) params.set(key, value);
  });
  const query = params.toString() ? `?${params.toString()}` : '';
  return request(`/admin/moderacao/alertas${query}`);
};

export const fetchModeracaoStats = () => request('/admin/moderacao/estatisticas');

export const atualizarModeracaoStatus = (alertaId, status) =>
  request(`/admin/moderacao/alertas/${alertaId}/status?status=${encodeURIComponent(status)}`, {
    method: 'POST'
  });

export const removerMensagemModeracao = (mensagemId) =>
  request(`/admin/moderacao/mensagens/${mensagemId}`, { method: 'DELETE' });

export const suspenderUsuarioModeracao = (usuarioId) =>
  request(`/admin/moderacao/usuarios/${usuarioId}/suspender`, { method: 'POST' });
